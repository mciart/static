const { app, BrowserWindow, ipcMain, shell } = require('electron');
const path = require('path');

app.commandLine.appendSwitch('use-angle', 'gl'); // 改成 OpenGL
app.commandLine.appendSwitch('disable-gpu-sandbox'); // 禁用 GPU 沙箱

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1024,
    height: 640,
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js')
    },
    icon: path.join(__dirname, 'icon.png'), // 如果有图标的话
    titleBarStyle: 'default',
    resizable: true
  });

  // 改为默认最大化而不是全屏
  mainWindow.maximize();
  
  mainWindow.loadFile('index.html');

  // 处理窗口关闭事件
  mainWindow.on('close', (event) => {
    if (process.platform === 'darwin') {
      // 在macOS上，点击红色关闭按钮时完全退出应用
      app.quit();
    }
  });

  // 开发时打开开发者工具
  // mainWindow.webContents.openDevTools();
}

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) {
    createWindow();
  }
});

// IPC 处理器
ipcMain.handle('e_center', () => {
  if (mainWindow) {
    mainWindow.center();
  }
});

ipcMain.handle('e_fullScreen', () => {
  if (mainWindow) {
    mainWindow.setFullScreen(!mainWindow.isFullScreen());
  }
});

ipcMain.handle('e_window', () => {
  if (mainWindow) {
    mainWindow.setFullScreen(false);
  }
});

ipcMain.handle('e_openURL', (event, url) => {
  shell.openExternal(url);
});

ipcMain.handle('e_openDevTools', () => {
  if (mainWindow) {
    mainWindow.webContents.openDevTools();
  }
});

ipcMain.handle('e_closeDevTools', () => {
  if (mainWindow) {
    mainWindow.webContents.closeDevTools();
  }
});

ipcMain.handle('e_setSize', (event, width, height) => {
  if (mainWindow) {
    mainWindow.setSize(parseInt(width), parseInt(height));
  }
});

ipcMain.handle('e_isFullScreen', () => {
  return mainWindow ? mainWindow.isFullScreen() : false;
});

ipcMain.handle('e_quit', () => {
  app.quit();
});